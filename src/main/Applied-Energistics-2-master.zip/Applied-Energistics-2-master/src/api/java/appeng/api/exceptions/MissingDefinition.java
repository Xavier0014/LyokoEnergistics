package appeng.api.exceptions;


public class MissingDefinition extends RuntimeException
{
	public MissingDefinition( String message )
	{
		super( message );
	}
}
