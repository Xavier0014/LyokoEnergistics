package appeng.api.exceptions;


public class CoreInaccessibleException extends RuntimeException
{
	public CoreInaccessibleException( String message )
	{
		super( message );
	}
}
