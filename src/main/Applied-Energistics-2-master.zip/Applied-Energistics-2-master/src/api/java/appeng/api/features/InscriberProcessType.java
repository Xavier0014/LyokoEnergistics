package appeng.api.features;


public enum InscriberProcessType
{
	/**
	 * uses the optionals as catalyst
	 */
	Inscribe,

	/**
	 * spends the optionals
	 */
	Press
}
